/* Program to print first, middle and last names.*/
#include<iostream>
#include<cstring>
using namespace std;
int main()
  {
   string first_name, middle_name, last_name;
   cout<<"Enter your first name: ";
   cin>>first_name;
   cout<<"Enter your middle_name: ";
   cin>>middle_name;
   cout<<"Enter your last_name: ";
   cin>>last_name;
   cout<<"Your full name is: ";
   cout<<first_name<<" "<<middle_name<<" "<<last_name<<endl;
   cout<<first_name.length();
   cin.ignore();
   cin.get();
   return 0;
  } 
        
