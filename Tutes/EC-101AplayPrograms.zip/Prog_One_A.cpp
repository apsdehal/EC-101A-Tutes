/* Program to print name, year, branch, address, etc.*/
#include<iostream>
//#include<cstring>
using namespace std;
int main()
  {
   string name, year, branch, address;
   cout<<"Enter your name: ";
   getline(cin, name, '$');
   cout<<"Enter your year of study: ";
   getline(cin, year, '$');
   cout<<"Enter your branch: ";
   getline(cin, branch, '$');
   cout<<"Enter your address: ";
   getline(cin, address, '$');
   cout<<name;
   cout<<year;
   cout<<branch;
   cout<<address;
   cin.ignore();
   cin.get();
   return 0;
  } 
        
