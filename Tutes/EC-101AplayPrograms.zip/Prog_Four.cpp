/* Program to explain declaration of variable, initialization
addition and also to display the results*/
#include<iostream>
#include<string>
using namespace std;
int main()
  {
   int noOfNotes,total = 0;
   cout<<"How many ten rupees notes do you have? ";
   cin>>noOfNotes;
   total = total + noOfNotes * 10; 
   cout<<"How many hundred rupees notes do you have? ";
   cin>>noOfNotes;
   total = total + noOfNotes * 100;
   cout<<"How many thousands rupees notes do you have? ";
   cin>>noOfNotes;
   total = total + noOfNotes * 1000;
   cout<<"Total amount in Rs. = "<<total;
   cin.ignore();
   cin.get();
   return 0;
  } 
        
