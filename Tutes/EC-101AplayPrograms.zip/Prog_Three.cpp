/* Program to explain declaration of variable, initialization
addition and also to display the results*/
#include<iostream>
#include<string>
using namespace std;
int main()
  {
   int noOfTens, noOfHundreds, noOfThousands, total;
   cout<<"How many ten rupees notes do you have? ";
   cin>>noOfTens;
   cout<<"How many hundred rupees notes do you have? ";
   cin>>noOfHundreds;
   cout<<"How many thousands rupees notes do you have? ";
   cin>>noOfThousands;
   total = noOfTens * 10 + noOfHundreds * 100 + noOfThousands *1000;
   cout<<"Total amount in Rs. = "<<total; 
   cin.ignore();
   cin.get();
   return 0;
  } 
        
