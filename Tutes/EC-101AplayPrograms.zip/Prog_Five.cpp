/* Program to display initials of first and middle names
and the last name, i.e., to display Ram Kumar Garg as R. K. Garg*/
#include<iostream>
#include<string>
using namespace std;
int main()
  {
   string first, middle, last;
   cout<<"Enter first, middle and last names:";
   cin>>first>>middle>>last;
   cout<<first<<" "<<middle<<" "<<last<<endl;
   first = first.substr(0, 1);
   middle = middle.substr(0, 1);
   cout<<first<<". "<<middle<<". "<<last<<endl;
   last = last.substr(0, 1);
   cout<<first<<middle<<last<<endl;
   cin.ignore();
   cin.get();
   return 0;
  } 
        
