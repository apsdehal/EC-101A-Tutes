/* Program to print first, middle and last names.*/
#include<iostream>
#include<cstring>
using namespace std;
int main()
  {
   char name[79], branch[79];
   string month; int year;
   cout<<"Enter your first, middle and last names: ";
   cin.getline(name, 79);
   cout<<"Enter your branch: "<<endl;
   cin.getline(branch, 79);
   cout<<"When did you join I.I.T. Roorkee? "<<endl;
   cin>>month>>year;
   cout<<"Your name is: ";
   cout<<name<<endl;
   cout<<"Your branch is: ";
   cout<<branch<<endl;
   cout<<"You joined I.I.T. Roorkee in "<<month<<", "<<year<<"."<<endl;
   cin.ignore();
   cin.get();
   return 0;
  } 
        
