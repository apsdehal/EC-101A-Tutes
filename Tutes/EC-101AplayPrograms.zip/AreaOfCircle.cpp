/* A simple interactive program which computes the area and perimeter 
 * of a circle. 
 * Input: radius of circle in cm 
 * Output: area and perimeter of the circle
 * (c)2009 K M Singh, IIT-Roorkee 
 */
 
#include <iostream>      // Standard input-output streams
#include <cmath>         // Math library functions 

using namespace std;

const double PI = acos(-1.0); 

int main()
{
    double radius = 1.0; 
    double perimeter = 1.0, area = 1.0;  
    
    cout << "\t This program computes perimeter and area of a circle." 
         << "\n\t Please input the RADIUS of the circle (in cm)" << endl;
    
    cin >> radius;
    area = PI*radius*radius;
    perimeter = 2.0*PI*radius; 
    
    cout << "\t Area of the circle, \t\t A = " << area << " sq. cm" << endl;
    cout << "\t Perimeter of the circle, \t P = " << perimeter << "  cm \n" << endl;
    
       
    system("PAUSE");
    return EXIT_SUCCESS;
}

